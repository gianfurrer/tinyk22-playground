/**
 *--------------------------------------------------------------------\n
 *          HSLU T&A Hochschule Luzern Technik+Architektur            \n
 *--------------------------------------------------------------------\n
 *
 * \brief         Exercise 13 - Luxmeter
 * \file
 * \author        Christian Jost, christian.jost@hslu.ch
 * \date          25.05.2021
 *
 *--------------------------------------------------------------------
 */
#include <string.h>
#include "platform.h"
#include "ftm0.h"
#include "ftm3.h"
#include "term.h"
#include "i2c.h"
#include "util.h"
#include "adc0.h"
#include "ff.h"
#include "spi.h"
#include "wait.h"
#include "file.h"

#if SOLUTION == 0

// calulates the nr of TOF count for a given number of milliseconds
#define TOFS_MS(x)   ((uint16_t)(((FTM3_CLOCK / 1000) * x) / (FTM3_MODULO + 1)))


#define OUTPUT_RESISTOR_LOW()     (GPIOE->PDDR |= (1<<0))     // PTE0 = Output
#define OUTPUT_RESISTOR_HIGHZ()   (GPIOE->PDDR &= ~(1<<0))    // PTE0 = Input => High impedance

#define OUTPUT_DIODE_LOW()        (GPIOE->PDDR |= (1<<1))     // PTE1 = Output
#define OUTPUT_DIODE_HIGHZ()      (GPIOE->PDDR &= ~(1<<1))    // PTE1 = Input => High impedance


/**
 * The main function
 */
void main(void)
{
  uint16_t value1, value2;
  uint16_t count, count2;
  uint16_t seconds = 0;
  char buf[64];                       // buffer to build and send a string

  waitInit();
  ftm3Init();                         // init flex timer 3
  termInit(57600);                    // init terminal with a baudrate of 57600
  adc0Init();                         // init A/D converter
  spiInit();                          // init spi

  PORTE->PCR[0] = PORT_PCR_MUX(1);    // configure port mux of PTE0 and PTE1 to GPIO
  PORTE->PCR[1] = PORT_PCR_MUX(1);

  GPIOE->PDDR |= (1<<0) | (1<<1);      // Set PTE0 & PTE1 as output
  GPIOE->PCOR = (1<<0) | (1<<1);       // Set PTE0 & PTE1 to Low

  waitMs(100);                         // wait until card is ready


  // todo 13.01 configure blue led as output and disable the led


  // todo 13.03 create a file


  // todo 13.04 Datenlogger
  for(;;){}

  while(TRUE)
  {
    if (FTM3->SC & FTM_SC_TOF_MASK)    // check for timer overflow
    {
      FTM3->SC &= ~FTM_SC_TOF_MASK;   // overflow occurred => clear TOF flag
      count++;                        // count the number of TOF's
      count2++;

      // First measure after 50ms
      if (count == TOFS_MS(50))
      {
        buf[0] = '\0';                // clear the zero terminated string (char buffer)

        // todo convert the channel DP0 (see adc.h)
        value1 = adc0Get16BitValue(ADC_CH_DM0);

        OUTPUT_RESISTOR_HIGHZ();
        OUTPUT_DIODE_LOW();
      }

      // Second measure after 100ms
      if (count == TOFS_MS(100))
      {
        // todo convert the channel DP0 (see adc.h)
        value2 = adc0Get16BitValue(ADC_CH_DM0);

        OUTPUT_RESISTOR_LOW();
        OUTPUT_DIODE_HIGHZ();
      }

      // send data after 250ms
      if (count >= TOFS_MS(250))
      {
        // restart counter to wait again 250ms
        count = 0;
        // toggle PTC2 (blue led) on the tinyK22
        //GPIOC_PTOR = (1<<2);

        // todo write the value1 into the string
        utilStrcatNum16u(buf, sizeof(buf), value1);

        // todo write a ';' into the string
        utilStrcat(buf, sizeof(buf), ";");

        // todo write the value2 into the string
        utilStrcatNum16u(buf, sizeof(buf), value2);

        // sends the buffer to the notebook
        termWriteLine(buf);
      }

      if (count2 >= TOFS_MS(1000))
      {
        // increment seconds counter every 1000ms
        seconds++;
        count2 = 0;
      }

      if (((seconds % 1) == 0) && count2 == 0)
      {
        // Save data every x seconds
        fileWriteData(seconds, value1, value2);
      }
    }
  }
}
#endif
